insert into notebook.table2 values ('Katlego' , 'Boksburg' , '0723467544');
insert into notebook.table2 values ('Glenda' , 'Midrand' , '0678907754');
insert into notebook.table2 values ('Naleigh' , 'Dairnfern' , '0713425556');
insert into notebook.table2 values ('Suzan' , 'Tembisa' , '0823456743');
